package com.nition.enginedisplacmentconversion;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayConversionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_conversion);

        Intent intent = getIntent();
        String message = intent.getStringExtra(MainPage.EXTRA);

        //capture layout's textView and set string as its text
        TextView convertedValueView = findViewById(R.id.convertedValue);
        convertedValueView.setText(message);
    }
}
